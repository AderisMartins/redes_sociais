--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: social_media; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA social_media;


ALTER SCHEMA social_media OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: input; Type: TABLE; Schema: social_media; Owner: postgres
--

CREATE TABLE social_media.input (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    city character varying(255),
    flag_process smallint DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE social_media.input OWNER TO postgres;

--
-- Name: input_id_seq; Type: SEQUENCE; Schema: social_media; Owner: postgres
--

ALTER TABLE social_media.input ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME social_media.input_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: social_media_domain; Type: TABLE; Schema: social_media; Owner: postgres
--

CREATE TABLE social_media.social_media_domain (
    id integer NOT NULL,
    name character varying NOT NULL,
    created_at time without time zone DEFAULT now() NOT NULL
);


ALTER TABLE social_media.social_media_domain OWNER TO postgres;

--
-- Name: rede_social_id_seq; Type: SEQUENCE; Schema: social_media; Owner: postgres
--

ALTER TABLE social_media.social_media_domain ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME social_media.rede_social_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user; Type: TABLE; Schema: social_media; Owner: postgres
--

CREATE TABLE social_media."user" (
    id bigint NOT NULL,
    id_profile character varying(50),
    id_photo character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_social_media_domain integer NOT NULL,
    id_input bigint
);


ALTER TABLE social_media."user" OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: social_media; Owner: postgres
--

ALTER TABLE social_media."user" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME social_media.usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 99999999999999999
    CACHE 1
);


--
-- Data for Name: input; Type: TABLE DATA; Schema: social_media; Owner: postgres
--

COPY social_media.input (id, email, name, created_at, city, flag_process, updated_at) FROM stdin;
\.
COPY social_media.input (id, email, name, created_at, city, flag_process, updated_at) FROM '$$PATH$$/3015.dat';

--
-- Data for Name: social_media_domain; Type: TABLE DATA; Schema: social_media; Owner: postgres
--

COPY social_media.social_media_domain (id, name, created_at) FROM stdin;
\.
COPY social_media.social_media_domain (id, name, created_at) FROM '$$PATH$$/3013.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: social_media; Owner: postgres
--

COPY social_media."user" (id, id_profile, id_photo, created_at, id_social_media_domain, id_input) FROM stdin;
\.
COPY social_media."user" (id, id_profile, id_photo, created_at, id_social_media_domain, id_input) FROM '$$PATH$$/3010.dat';

--
-- Name: input_id_seq; Type: SEQUENCE SET; Schema: social_media; Owner: postgres
--

SELECT pg_catalog.setval('social_media.input_id_seq', 574, true);


--
-- Name: rede_social_id_seq; Type: SEQUENCE SET; Schema: social_media; Owner: postgres
--

SELECT pg_catalog.setval('social_media.rede_social_id_seq', 1, true);


--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: social_media; Owner: postgres
--

SELECT pg_catalog.setval('social_media.usuario_id_seq', 457, true);


--
-- Name: input input_pkey; Type: CONSTRAINT; Schema: social_media; Owner: postgres
--

ALTER TABLE ONLY social_media.input
    ADD CONSTRAINT input_pkey PRIMARY KEY (id);


--
-- Name: social_media_domain rede_social_pkey; Type: CONSTRAINT; Schema: social_media; Owner: postgres
--

ALTER TABLE ONLY social_media.social_media_domain
    ADD CONSTRAINT rede_social_pkey PRIMARY KEY (id);


--
-- Name: user unique_user; Type: CONSTRAINT; Schema: social_media; Owner: postgres
--

ALTER TABLE ONLY social_media."user"
    ADD CONSTRAINT unique_user UNIQUE (id_profile, id_photo);


--
-- Name: user usuario_pkey; Type: CONSTRAINT; Schema: social_media; Owner: postgres
--

ALTER TABLE ONLY social_media."user"
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: user fk_user_input; Type: FK CONSTRAINT; Schema: social_media; Owner: postgres
--

ALTER TABLE ONLY social_media."user"
    ADD CONSTRAINT fk_user_input FOREIGN KEY (id_input) REFERENCES social_media.input(id) NOT VALID;


--
-- Name: user fk_user_rede_social; Type: FK CONSTRAINT; Schema: social_media; Owner: postgres
--

ALTER TABLE ONLY social_media."user"
    ADD CONSTRAINT fk_user_rede_social FOREIGN KEY (id_social_media_domain) REFERENCES social_media.social_media_domain(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

